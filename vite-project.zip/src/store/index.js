import { createStore } from 'vuex';
import sample from '@/store/modules/sample.js';

export default createStore({
	modules: { sample },
});

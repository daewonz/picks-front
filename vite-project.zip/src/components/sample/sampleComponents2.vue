<script setup></script>
<template>
	<div class="gd">안녕하세요 컴포넌트 샘플입니다. 이렇게 붙여서 사용합니다2</div>
</template>
<style>
.gd {
	background-color: yellowgreen;
}
</style>

<script setup></script>
<template>
	<div>안녕하세요 컴포넌트 샘플입니다. 이렇게 붙여서 사용합니다!!</div>
</template>
<style></style>
